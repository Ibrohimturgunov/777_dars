
# cd.delete_info('university','talaba', 'kursi=4')
# cd.update_table('university', 'update talaba set kursi=kursi+1')